export default function Evaluation() {
  return (
    <section className="rounded-[15px] border border-[#e4e9f0] bg-white p-8 shadow-[0px_10px_30px_#2239560b]">
      <h1 className="text-2xl font-bold text-[#172136]">평가관리</h1>
      <p className="mt-3 text-sm text-[#71869d]">평가관리 화면은 아직 구현되지 않았습니다. 평가 항목, 평가 대상자, 평가 기간을 이 화면에 연결할 수 있습니다.</p>
    </section>
  );
}
