import { useMemo, useState, type JSX } from "react";

type Department = {
  id: string;
  name: string;
  parent: string;
  members: number;
};

const departments: Department[] = [
  { id: "DEP-001", name: "경영지원본부", parent: "최상위 부서", members: 18 },
  { id: "DEP-002", name: "인사팀", parent: "경영지원본부", members: 8 },
  { id: "DEP-003", name: "재무회계팀", parent: "경영지원본부", members: 7 },
  { id: "DEP-004", name: "사업본부", parent: "최상위 부서", members: 42 },
  { id: "DEP-005", name: "서비스개발팀", parent: "사업본부", members: 24 },
];

export const DepartmentManagementSection = (): JSX.Element => {
  const [selectedId, setSelectedId] = useState("DEP-001");
  const [query, setQuery] = useState("");
  const [activeOnly, setActiveOnly] = useState(false);
  const [form, setForm] = useState({
    name: "경영지원본부",
    code: "DEP-001",
    parent: "최상위 부서",
    description: "전사 경영지원 및 운영 업무를 담당합니다.",
    leader: "김하늘",
    members: "18",
  });

  const filteredDepartments = useMemo(
    () =>
      departments.filter((department) => {
        const matchesQuery =
          department.name.includes(query) || department.id.includes(query);
        const matchesActive = !activeOnly || department.members > 0;
        return matchesQuery && matchesActive;
      }),
    [activeOnly, query],
  );

  const selectedDepartment =
    departments.find((department) => department.id === selectedId) ??
    departments[0];

  const updateField = (field: keyof typeof form, value: string) => {
    setForm((current) => ({ ...current, [field]: value }));
  };

  const selectDepartment = (department: Department) => {
    setSelectedId(department.id);
    setForm({
      name: department.name,
      code: department.id,
      parent: department.parent,
      description:
        department.id === "DEP-001"
          ? "전사 경영지원 및 운영 업무를 담당합니다."
          : "",
      leader: department.id === "DEP-001" ? "김하늘" : "",
      members: String(department.members),
    });
  };

  const saveChanges = () => {
    setSelectedId(form.code);
  };

  return (
    <div className="grid grid-cols-[385px_650px] grid-rows-[505.50px] min-h-[438px] h-fit gap-4">
      <section
        aria-label="부서 목록"
        className="col-[1_/_2] relative row-[1_/_2] w-full h-full flex flex-col items-start bg-white rounded-lg overflow-hidden border border-solid border-[#e1e9f2]"
      >
        <div className="flex h-[58px] items-start gap-2 px-[13px] py-[11px] relative self-stretch w-full border-b [border-bottom-style:solid] border-[#edf1f6]">
          <label className="flex items-center gap-2 px-[11px] py-0 bg-[#fafcff] rounded-[5px] border border-solid border-[#dfe7f0]">
            <span className="relative w-[15.61px] h-[17px]" aria-hidden="true">
              <img
                className="absolute w-[87.08%] h-[84.05%] top-[15.95%] left-[12.92%]"
                alt=""
                src="/img/vector.svg"
              />
              <img
                className="absolute w-[37.08%] h-[38.14%] top-[61.86%] left-[62.92%]"
                alt=""
                src="/img/vector-1.svg"
              />
            </span>
            <input
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              aria-label="부서명 또는 코드 검색"
              placeholder="부서명 또는 코드 검색"
              className="relative w-[265.39px] h-[17.25px] [font-family:'Noto_Sans_KR',Helvetica] font-normal text-[#395a7a] text-[11.5px] tracking-[0] leading-[normal] placeholder:text-[#97a7ba]"
            />
          </label>
          <button
            type="button"
            aria-label="부서 목록 메뉴"
            className="all-unset box-border flex flex-col w-9 items-center justify-center relative self-stretch bg-white rounded-[5px] border border-solid border-[#dfe7f0]"
          >
            <span className="relative w-fit [font-family:'Noto_Sans_KR',Helvetica] font-normal text-[#7790ad] text-base text-center tracking-[1.00px] leading-6 whitespace-nowrap">
              •••
            </span>
          </button>
        </div>
        <div className="flex h-[38px] items-center justify-between px-3.5 py-0 relative self-stretch w-full bg-[#f8fafd]">
          <span className="relative w-fit [font-family:'Noto_Sans_KR',Helvetica] font-normal text-[#7890ad] text-[10.5px] tracking-[0] leading-[15.8px] whitespace-nowrap">
            전체 {departments.length}개
          </span>
          <button
            type="button"
            aria-pressed={activeOnly}
            onClick={() => setActiveOnly((value) => !value)}
            className="all-unset box-border inline-flex flex-col items-center justify-center relative"
          >
            <span className="relative w-fit [font-family:'Noto_Sans_KR',Helvetica] font-normal text-[#56789f] text-[10.5px] text-center tracking-[0] leading-[15.8px] whitespace-nowrap">
              사용 중인 항목만
            </span>
          </button>
        </div>
        <div className="flex flex-col items-start px-[7px] py-[5px]">
          {filteredDepartments.map((department, index) => {
            const selected = department.id === selectedId;
            return (
              <button
                type="button"
                key={department.id}
                onClick={() => selectDepartment(department)}
                aria-pressed={selected}
                className={`flex w-[369px] h-[58px] items-center gap-2.5 px-2.5 py-2 relative ${
                  selected ? "bg-[#cff6ff]" : "bg-white"
                } ${
                  index < filteredDepartments.length - 1
                    ? "border-b [border-bottom-style:solid] border-[#edf1f5]"
                    : ""
                } ${selected ? "rounded-md border-transparent" : ""}`}
              >
                <span
                  className={`grid grid-cols-[27px] grid-rows-[27px] w-[27px] h-[27px] ${
                    selected ? "bg-[#dbeaff]" : "bg-[#f0f4f8]"
                  } rounded-md`}
                >
                  <span
                    className={`relative row-[1_/_2] col-[1_/_2] justify-self-center self-center w-2.5 h-3.5 [font-family:'Noto_Sans_KR',Helvetica] font-normal ${
                      selected ? "text-[#1973e8]" : "text-[#7d93ad]"
                    } text-[9px] tracking-[0] leading-[13.5px] whitespace-nowrap`}
                  ></span>
                </span>
                <span className="flex flex-col items-start text-left">
                  <span className="[font-family:'Noto_Sans_KR',Helvetica] font-bold text-[#294968] text-xs tracking-[0] leading-[18px] whitespace-nowrap">
                    {department.name}
                  </span>
                  <span className="pt-[5px] [font-family:'Noto_Sans_KR',Helvetica] font-normal text-[#8799ae] text-[9.5px] tracking-[0] leading-[14.2px] whitespace-nowrap">
                    {department.id} · {department.parent}
                  </span>
                </span>
                <span className="relative ml-auto w-[24.45px] h-[18px]">
                  <span className="absolute -top-0.5 left-0 [font-family:'Noto_Sans_KR',Helvetica] font-bold text-[#365c85] text-xs tracking-[0] leading-[18px] whitespace-nowrap">
                    {department.members}
                  </span>
                  <span className="absolute top-[3px] left-4 text-[#8799ae] text-[9px] tracking-[0] leading-[13.5px] [font-family:'Noto_Sans_KR',Helvetica] font-normal whitespace-nowrap">
                    명
                  </span>
                </span>
                <span className="relative w-4 h-4" aria-hidden="true">
                  <img
                    className="absolute w-[66.25%] h-[78.75%] top-[21.25%] left-[33.75%]"
                    alt=""
                    src="/img/vector-6.svg"
                  />
                </span>
              </button>
            );
          })}
        </div>
        <div className="flex h-[39px] items-center gap-[7px] px-3.5 py-0 relative self-stretch w-full bg-[#fafcff] border-t [border-top-style:solid] border-[#e9eef4] mt-auto">
          <span className="relative w-[15px] h-[15px]" aria-hidden="true">
            <img
              className="absolute w-[95.42%] h-[95.42%] top-[4.58%] left-[4.58%]"
              alt=""
              src="/img/vector-7.svg"
            />
            <img
              className="absolute w-[53.75%] h-[74.58%] top-[25.42%] left-[46.25%]"
              alt=""
              src="/img/vector-8.svg"
            />
          </span>
          <p className="relative w-fit [font-family:'Noto_Sans_KR',Helvetica] font-normal text-[#7b90a9] text-[9.5px] tracking-[0] leading-[14.2px] whitespace-nowrap">
            항목을 선택하면 상세 정보를 수정할 수 있습니다.
          </p>
        </div>
      </section>
      <section className="col-[2_/_3] pt-0 pb-[58px] px-0 relative row-[1_/_2] w-full h-full flex flex-col items-start bg-white rounded-lg overflow-hidden border border-solid border-[#e1e9f2]">
        <header className="flex h-[78px] items-center gap-[13px] px-5 py-0 relative self-stretch w-full border-b [border-bottom-style:solid] border-[#e8edf3]">
          <img
            className="grid grid-cols-[42px] grid-rows-[42px] w-[42px] h-[42px]"
            alt="부서 아이콘"
            src="/img/container.svg"
          />
          <div className="flex flex-col w-[150px] items-start relative">
            <span className="text-[#7e93ad] text-[9px] tracking-[0.36px] leading-[13.5px] [font-family:'Noto_Sans_KR',Helvetica]">
              {selectedDepartment.id}
            </span>
            <h2 className="pt-1 [font-family:'Noto_Sans_KR',Helvetica] font-normal text-[#193a61] text-base tracking-[0] leading-6 whitespace-nowrap">
              {selectedDepartment.name}
            </h2>
          </div>
        </header>
        <form
          onSubmit={(event) => {
            event.preventDefault();
            saveChanges();
          }}
          className="flex flex-col items-start pt-[17px] pb-3 px-5 relative self-stretch w-full flex-[0_0_auto]"
        >
          <div className="flex items-center gap-[9px] relative self-stretch w-full">
            <h3 className="[font-family:'Noto_Sans_KR',Helvetica] font-bold text-[#365775] text-[11.5px] tracking-[0] leading-[17.2px]">
              기본 정보
            </h3>
            <span className="[font-family:'Noto_Sans_KR',Helvetica] font-normal text-[#94a4b6] text-[9.5px] tracking-[0] leading-[14.2px]">
              필수 정보를 입력해주세요.
            </span>
          </div>
          <div className="items-start pt-3 flex flex-col relative self-stretch w-full">
            <div className="grid grid-cols-[297.50px_297.50px] grid-rows-[51.25px_51.25px_73.25px] h-fit gap-[11px_13px]">
              <label className="row-[1_/_2] col-[1_/_2] relative w-full h-full flex flex-col items-start">
                <span className="h-[21px] pt-0 pb-1.5 [font-family:'Noto_Sans_KR',Helvetica] text-[#657e9b] text-[9.5px]">
                  부서명 <strong className="text-[#ed5862]">*</strong>
                </span>
                <input
                  required
                  value={form.name}
                  onChange={(event) => updateField("name", event.target.value)}
                  className="flex flex-col w-[297.5px] h-[31px] justify-center px-[9px] bg-white rounded-[5px] border border-solid border-[#dfe7f0] [font-family:'Noto_Sans_KR',Helvetica] text-[#395a7a] text-[11px]"
                />
              </label>
              <label className="row-[1_/_2] col-[2_/_3] relative w-full h-full flex flex-col items-start">
                <span className="h-[21px] pt-0 pb-1.5 [font-family:'Noto_Sans_KR',Helvetica] text-[#657e9b] text-[9.5px]">
                  부서 코드 <strong className="text-[#ed5862]">*</strong>
                </span>
                <input
                  required
                  value={form.code}
                  onChange={(event) => updateField("code", event.target.value)}
                  className="flex flex-col w-[297.5px] h-[31px] justify-center px-[9px] bg-white rounded-[5px] border border-solid border-[#dfe7f0] [font-family:'Noto_Sans_KR',Helvetica] text-[#395a7a] text-[11px]"
                />
              </label>
              <label className="row-[2_/_3] col-[1_/_3] relative w-full h-full flex flex-col items-start">
                <span className="h-[21px] pt-0 pb-1.5 [font-family:'Noto_Sans_KR',Helvetica] text-[#657e9b] text-[9.5px]">
                  상위 부서
                </span>
                <select
                  value={form.parent}
                  onChange={(event) =>
                    updateField("parent", event.target.value)
                  }
                  className="relative self-stretch w-full h-[31px] px-3.5 bg-white rounded-[5px] border border-solid border-[#dfe7f0] [font-family:'Noto_Sans_KR',Helvetica] text-[#395a7a] text-[11px]"
                >
                  <option>최상위 부서</option>
                  <option>경영지원본부</option>
                  <option>사업본부</option>
                </select>
              </label>
              <label className="row-[3_/_4] col-[1_/_3] relative w-full h-full flex flex-col items-start">
                <span className="h-[21px] pt-0 pb-1.5 [font-family:'Noto_Sans_KR',Helvetica] text-[#657e9b] text-[9.5px]">
                  설명
                </span>
                <textarea
                  value={form.description}
                  onChange={(event) =>
                    updateField("description", event.target.value)
                  }
                  className="w-[608px] h-12 p-[9px] resize-none bg-white rounded-[5px] border border-solid border-[#dfe7f0] [font-family:'Noto_Sans_KR',Helvetica] text-[#395a7a] text-[11px] leading-[16.5px]"
                />
              </label>
            </div>
          </div>
          <div className="items-center pt-[17px] flex flex-col relative self-stretch w-full">
            <div className="flex items-center gap-[9px] pt-[15px] relative self-stretch w-full border-t [border-top-style:solid] border-[#edf1f5]">
              <h3 className="[font-family:'Noto_Sans_KR',Helvetica] font-bold text-[#365775] text-[11.5px] tracking-[0] leading-[17.2px]">
                운영 정보
              </h3>
              <span className="[font-family:'Noto_Sans_KR',Helvetica] font-normal text-[#94a4b6] text-[9.5px] tracking-[0] leading-[14.2px]">
                부서 운영에 필요한 추가 설정입니다.
              </span>
            </div>
          </div>
          <div className="items-start pt-2.5 flex flex-col relative self-stretch w-full">
            <div className="grid grid-cols-[297.50px_297.50px] grid-rows-[51.25px] h-fit gap-[11px_13px]">
              <label className="relative w-full h-full flex flex-col items-start">
                <span className="h-[21px] [font-family:'Noto_Sans_KR',Helvetica] text-[#657e9b] text-[9.5px]">
                  부서장
                </span>
                <input
                  value={form.leader}
                  onChange={(event) =>
                    updateField("leader", event.target.value)
                  }
                  className="flex flex-col w-[297.5px] h-[31px] justify-center px-[9px] bg-white rounded-[5px] border border-solid border-[#dfe7f0] [font-family:'Noto_Sans_KR',Helvetica] text-[#395a7a] text-[11px]"
                />
              </label>
              <label className="relative w-full h-full flex flex-col items-start">
                <span className="h-[21px] [font-family:'Noto_Sans_KR',Helvetica] text-[#657e9b] text-[9.5px]">
                  현재 인원
                </span>
                <span className="relative w-full h-[31px]">
                  <input
                    type="number"
                    min="0"
                    value={form.members}
                    onChange={(event) =>
                      updateField("members", event.target.value)
                    }
                    className="w-[298px] h-[31px] pl-[9px] pr-[30px] bg-white rounded-[5px] border border-solid border-[#dfe7f0] [font-family:'Noto_Sans_KR',Helvetica] text-[#395a7a] text-[11px]"
                  />
                  <span className="absolute top-[9px] left-[279px] [font-family:'Noto_Sans_KR',Helvetica] text-[#8497ae] text-[9px]">
                    명
                  </span>
                </span>
              </label>
            </div>
          </div>
          <footer className="flex w-[648px] h-[57px] items-center justify-end gap-2 px-5 py-0 absolute top-[448px] left-px bg-[#fbfcfe] border-t [border-top-style:solid] border-[#e7edf4]">
            <div className="flex items-start relative flex-1 grow">
              <button
                type="button"
                onClick={() => {
                  if (window.confirm("선택한 부서를 삭제하시겠습니까?")) {
                    setSelectedId(departments[0].id);
                  }
                }}
                className="all-unset box-border inline-flex h-[31px] items-center gap-[5px] px-[13px] rounded-[5px]"
              >
                <img
                  className="relative w-4 h-4"
                  alt=""
                  src="/img/vector-10.svg"
                />
                <span className="[font-family:'Noto_Sans_KR',Helvetica] text-[#e65a62] text-[10.5px]">
                  삭제
                </span>
              </button>
            </div>
            <button
              type="button"
              onClick={() => selectDepartment(selectedDepartment)}
              className="all-unset box-border inline-flex h-[31px] items-center justify-center px-[13px] bg-white rounded-[5px] border border-solid border-[#dae4ee] [font-family:'Noto_Sans_KR',Helvetica] text-[#647d9b] text-[10.5px]"
            >
              취소
            </button>
            <button
              type="submit"
              className="all-unset box-border inline-flex h-[31px] items-center justify-center px-[13px] bg-[#15b9dc] rounded-[5px] [font-family:'Noto_Sans_KR',Helvetica] text-white text-[10.5px]"
            >
              변경사항 저장
            </button>
          </footer>
        </form>
      </section>
    </div>
  );
};
