import { useMemo, useState, type JSX } from "react";

type Job = {
  number: string;
  name: string;
  code: string;
  category: string;
  group: string;
  count: number;
  description: string;
};

const jobs: Job[] = [
  {
    number: "01",
    name: "프론트엔드 개발",
    code: "JOB-DEV-01",
    category: "개발 · 서비스개발",
    group: "개발",
    count: 13,
    description: "웹 기반 사용자 인터페이스를 설계하고 개발합니다.",
  },
  {
    number: "02",
    name: "백엔드 개발",
    code: "JOB-DEV-02",
    category: "개발 · 서비스개발",
    group: "개발",
    count: 16,
    description: "서버와 데이터베이스를 설계하고 개발합니다.",
  },
  {
    number: "03",
    name: "프로덕트 디자인",
    code: "JOB-DES-01",
    category: "디자인 · UX/UI",
    group: "디자인",
    count: 7,
    description: "사용자 경험과 제품 인터페이스를 설계합니다.",
  },
  {
    number: "04",
    name: "서비스 기획",
    code: "JOB-PLAN-01",
    category: "기획 · 서비스전략",
    group: "기획",
    count: 9,
    description: "서비스 전략과 제품 요구사항을 기획합니다.",
  },
  {
    number: "05",
    name: "HR 매니지먼트",
    code: "JOB-HR-01",
    category: "경영지원 · 인사",
    group: "경영지원",
    count: 6,
    description: "조직과 구성원의 인사 운영을 관리합니다.",
  },
];

export const JobManagementSection = (): JSX.Element => {
  const [selectedJob, setSelectedJob] = useState<Job>(jobs[0]);
  const [search, setSearch] = useState("");
  const [showActiveOnly, setShowActiveOnly] = useState(false);
  const [jobName, setJobName] = useState(jobs[0].name);
  const [jobCode, setJobCode] = useState(jobs[0].code);
  const [category, setCategory] = useState(jobs[0].category);
  const [description, setDescription] = useState(jobs[0].description);
  const [group, setGroup] = useState(jobs[0].group);
  const [headcount, setHeadcount] = useState(String(jobs[0].count));

  const filteredJobs = useMemo(() => {
    const normalizedSearch = search.trim().toLowerCase();

    return jobs.filter((job) => {
      const matchesSearch =
        normalizedSearch.length === 0 ||
        job.name.toLowerCase().includes(normalizedSearch) ||
        job.code.toLowerCase().includes(normalizedSearch);

      const matchesActive = !showActiveOnly || job.count > 0;

      return matchesSearch && matchesActive;
    });
  }, [search, showActiveOnly]);

  const selectJob = (job: Job) => {
    setSelectedJob(job);
    setJobName(job.name);
    setJobCode(job.code);
    setCategory(job.category);
    setDescription(job.description);
    setGroup(job.group);
    setHeadcount(String(job.count));
  };

  const resetForm = () => {
    selectJob(selectedJob);
  };

  const saveChanges = () => {
    setSelectedJob({
      ...selectedJob,
      name: jobName,
      code: jobCode,
      category,
      description,
      group,
      count: Number(headcount) || 0,
    });
  };

  return (
    <div className="grid grid-cols-[385px_650px] grid-rows-[505.50px] min-h-[438px] h-fit gap-4">
      <section
        aria-label="직무 목록"
        className="col-[1_/_2] relative row-[1_/_2] w-full h-full flex flex-col items-start bg-white rounded-lg overflow-hidden border border-solid border-[#e1e9f2]"
      >
        <div className="flex h-[58px] items-start gap-2 px-[13px] py-[11px] relative self-stretch w-full border-b [border-bottom-style:solid] border-[#edf1f6]">
          <label className="flex items-center gap-2 px-[11px] py-0 bg-[#fafcff] rounded-[5px] border border-solid border-[#dfe7f0]">
            <span className="relative w-[15.61px] h-[17px]" aria-hidden="true">
              <img
                className="absolute w-[87.08%] h-[84.05%] top-[15.95%] left-[12.92%]"
                alt=""
                src="/img/vector.svg"
              />
              <img
                className="absolute w-[37.08%] h-[38.14%] top-[61.86%] left-[62.92%]"
                alt=""
                src="/img/vector-1.svg"
              />
            </span>
            <span className="flex flex-col w-[265.39px] h-[17.25px] items-start justify-center relative">
              <input
                aria-label="직무명 또는 코드 검색"
                value={search}
                onChange={(event) => setSearch(event.target.value)}
                placeholder="직무명 또는 코드 검색"
                className="relative self-stretch [font-family:'Noto_Sans_KR',Helvetica] font-normal text-[#395a7a] text-[11.5px] tracking-[0] leading-[normal] placeholder:text-[#97a7ba]"
              />
            </span>
          </label>
          <button
            type="button"
            aria-label="추가 메뉴"
            className="all-unset box-border flex flex-col w-9 items-center justify-center relative self-stretch bg-white rounded-[5px] border border-solid border-[#dfe7f0]"
          >
            <span className="relative w-fit [font-family:'Noto_Sans_KR',Helvetica] font-normal text-[#7790ad] text-base text-center tracking-[1.00px] leading-6 whitespace-nowrap">
              •••
            </span>
          </button>
        </div>
        <div className="flex h-[38px] items-center justify-between px-3.5 py-0 relative self-stretch w-full bg-[#f8fafd]">
          <div className="inline-flex flex-col items-start relative flex-[0_0_auto]">
            <span className="relative w-fit mt-[-1.00px] [font-family:'Noto_Sans_KR',Helvetica] font-normal text-[#7890ad] text-[10.5px] tracking-[0] leading-[15.8px] whitespace-nowrap">
              전체 {filteredJobs.length}개
            </span>
          </div>
          <button
            type="button"
            aria-pressed={showActiveOnly}
            onClick={() => setShowActiveOnly((value) => !value)}
            className="all-unset box-border inline-flex flex-col items-center justify-center relative flex-[0_0_auto]"
          >
            <span className="relative w-fit mt-[-1.00px] [font-family:'Noto_Sans_KR',Helvetica] font-normal text-[#56789f] text-[10.5px] text-center tracking-[0] leading-[15.8px] whitespace-nowrap">
              사용 중인 항목만
            </span>
          </button>
        </div>
        <div className="flex flex-col items-start px-[7px] py-[5px]">
          {filteredJobs.map((job, _index) => (
            <button
              type="button"
              key={job.code}
              onClick={() => selectJob(job)}
              aria-current={selectedJob.code === job.code ? "true" : undefined}
              className={`flex w-[369px] h-[58px] items-center gap-2.5 px-2.5 py-2 relative ${
                selectedJob.code === job.code
                  ? "bg-[#cff7ff] rounded-md border-b [border-bottom-style:solid] border-transparent"
                  : "bg-white border-b [border-bottom-style:solid] border-[#edf1f5]"
              }`}
            >
              <span
                className={`grid grid-cols-[27px] grid-rows-[27px] w-[27px] h-[27px] rounded-md ${
                  selectedJob.code === job.code
                    ? "bg-[#dbeaff]"
                    : "bg-[#f0f4f8]"
                }`}
              >
                <span
                  className={`relative row-[1_/_2] col-[1_/_2] justify-self-center self-center w-2.5 h-3.5 [font-family:'Noto_Sans_KR',Helvetica] font-normal text-[9px] tracking-[0] leading-[13.5px] whitespace-nowrap ${
                    selectedJob.code === job.code
                      ? "text-[#1973e8]"
                      : "text-[#7d93ad]"
                  }`}
                >
                  {job.number}
                </span>
              </span>
              <span className="flex flex-col items-start text-left">
                <span className="flex flex-col items-start relative self-stretch w-full flex-[0_0_auto]">
                  <span className="relative w-fit mt-[-1.00px] [font-family:'Noto_Sans_KR',Helvetica] font-bold text-[#294968] text-xs tracking-[0] leading-[18px] whitespace-nowrap">
                    {job.name}
                  </span>
                </span>
                <span className="flex flex-col items-start pt-[5px] pb-0 px-0 relative self-stretch w-full flex-[0_0_auto]">
                  <span className="flex flex-col h-[14.25px] items-start relative self-stretch w-full">
                    <span className="relative w-fit mt-[-1.00px] [font-family:'Noto_Sans_KR',Helvetica] font-normal text-[#8799ae] text-[9.5px] tracking-[0] leading-[14.2px] whitespace-nowrap">
                      {job.code} · {job.category}
                    </span>
                  </span>
                </span>
              </span>
              <span className="relative w-[24.45px] h-[18px] ml-auto">
                <span className="absolute -top-0.5 left-0 [font-family:'Noto_Sans_KR',Helvetica] font-bold text-[#365c85] text-xs tracking-[0] leading-[18px] whitespace-nowrap">
                  {job.count}
                </span>
                <span className="absolute top-[3px] left-4 text-[#8799ae] text-[9px] tracking-[0] leading-[13.5px] [font-family:'Noto_Sans_KR',Helvetica] font-normal whitespace-nowrap">
                  명
                </span>
              </span>
              <span className="relative w-4 h-4" aria-hidden="true">
                <img
                  className="absolute w-[66.25%] h-[78.75%] top-[21.25%] left-[33.75%]"
                  alt=""
                  src="/img/vector-6.svg"
                />
              </span>
            </button>
          ))}
        </div>
        <div className="flex h-[39px] items-center gap-[7px] px-3.5 py-0 relative self-stretch w-full bg-[#fafcff] border-t [border-top-style:solid] border-[#e9eef4] mt-auto">
          <span className="relative w-[15px] h-[15px]" aria-hidden="true">
            <img
              className="absolute w-[95.42%] h-[95.42%] top-[4.58%] left-[4.58%]"
              alt=""
              src="/img/vector-7.svg"
            />
            <img
              className="absolute w-[53.75%] h-[74.58%] top-[25.42%] left-[46.25%]"
              alt=""
              src="/img/vector-8.svg"
            />
          </span>
          <span className="inline-flex flex-col items-start relative flex-[0_0_auto]">
            <span className="relative w-fit mt-[-1.00px] [font-family:'Noto_Sans_KR',Helvetica] font-normal text-[#7b90a9] text-[9.5px] tracking-[0] leading-[14.2px] whitespace-nowrap">
              항목을 선택하면 상세 정보를 수정할 수 있습니다.
            </span>
          </span>
        </div>
      </section>
      <section
        aria-label="직무 상세 정보"
        className="col-[2_/_3] pt-0 pb-[58px] px-0 relative row-[1_/_2] w-full h-full flex flex-col items-start bg-white rounded-lg overflow-hidden border border-solid border-[#e1e9f2]"
      >
        <header className="flex h-[78px] items-center gap-[13px] px-5 py-0 relative self-stretch w-full border-b [border-bottom-style:solid] border-[#e8edf3]">
          <div className="grid grid-cols-[42px] grid-rows-[42px] w-[42px] h-[42px] bg-[#e5f8f5] rounded-[9px]">
            <span
              className="relative row-[1_/_2] col-[1_/_2] justify-self-center self-center w-[25px] h-[25px]"
              aria-hidden="true"
            >
              <img
                className="absolute w-[91.25%] h-[74.58%] top-[25.42%] left-[8.75%]"
                alt=""
                src="/img/vector-9.svg"
              />
              <img
                className="absolute w-[91.25%] h-[87.08%] top-[12.92%] left-[8.75%]"
                alt=""
                src="/img/vector-10.svg"
              />
            </span>
          </div>
          <div className="flex flex-col w-[107.53px] items-start relative">
            <span className="relative w-fit mt-[-1.00px] [font-family:'Noto_Sans_KR',Helvetica] font-normal text-[#7e93ad] text-[9px] tracking-[0.36px] leading-[13.5px] whitespace-nowrap">
              {selectedJob.code}
            </span>
            <span className="w-[107.53px] h-7 pt-1 pb-0 px-0 flex flex-col items-start relative">
              <span className="relative w-fit mt-[-1.00px] [font-family:'Noto_Sans_KR',Helvetica] font-normal text-[#193a61] text-base tracking-[0] leading-6 whitespace-nowrap">
                {selectedJob.name}
              </span>
            </span>
          </div>
          <div className="relative flex-1 grow h-5" />
        </header>
        <form
          onSubmit={(event) => {
            event.preventDefault();
            saveChanges();
          }}
          className="flex flex-col items-start pt-[17px] pb-3 px-5 relative self-stretch w-full flex-[0_0_auto] mb-[-0.50px]"
        >
          <div className="flex items-center gap-[9px] relative self-stretch w-full flex-[0_0_auto]">
            <h2 className="font-bold text-[#365775] text-[11.5px] leading-[17.2px] relative w-fit mt-[-1.00px] [font-family:'Noto_Sans_KR',Helvetica] tracking-[0] whitespace-nowrap">
              기본 정보
            </h2>
            <span className="relative w-fit mt-[-1.00px] [font-family:'Noto_Sans_KR',Helvetica] font-normal text-[#94a4b6] text-[9.5px] tracking-[0] leading-[14.2px] whitespace-nowrap">
              필수 정보를 입력해주세요.
            </span>
          </div>
          <div className="items-start pt-3 pb-0 px-0 flex flex-col relative self-stretch w-full flex-[0_0_auto]">
            <div className="grid grid-cols-[297.50px_297.50px] grid-rows-[51.25px_51.25px_73.25px] h-fit gap-[11px_13px]">
              <label className="row-[1_/_2] col-[1_/_2] relative w-full h-full flex flex-col items-start">
                <span className="flex flex-col w-[297.5px] h-[21px] items-start pt-0 pb-1.5 px-0 relative">
                  <span className="font-normal text-[9.5px] leading-[14.2px] relative w-fit mt-[-1.00px] [font-family:'Noto_Sans_KR',Helvetica] tracking-[0] whitespace-nowrap">
                    <span className="text-[#657e9b]">직무명 </span>
                    <span className="font-bold text-[#ed5862]">*</span>
                  </span>
                </span>
                <input
                  required
                  value={jobName}
                  onChange={(event) => setJobName(event.target.value)}
                  className="flex flex-col w-[297.5px] h-[31px] items-start justify-center px-[9px] py-0 relative mb-[-0.75px] bg-white rounded-[5px] overflow-hidden border border-solid border-[#dfe7f0] [font-family:'Noto_Sans_KR',Helvetica] font-normal text-[#395a7a] text-[11px] tracking-[0] leading-[16.5px]"
                />
              </label>
              <label className="row-[1_/_2] col-[2_/_3] relative w-full h-full flex flex-col items-start">
                <span className="flex flex-col w-[297.5px] h-[21px] items-start pt-0 pb-1.5 px-0 relative">
                  <span className="font-normal text-[9.5px] leading-[14.2px] relative w-fit mt-[-1.00px] [font-family:'Noto_Sans_KR',Helvetica] tracking-[0] whitespace-nowrap">
                    <span className="text-[#657e9b]">직무 코드 </span>
                    <span className="font-bold text-[#ed5862]">*</span>
                  </span>
                </span>
                <input
                  required
                  value={jobCode}
                  onChange={(event) => setJobCode(event.target.value)}
                  className="flex flex-col w-[297.5px] h-[31px] items-start justify-center px-[9px] py-0 relative mb-[-0.75px] bg-white rounded-[5px] overflow-hidden border border-solid border-[#dfe7f0] [font-family:'Noto_Sans_KR',Helvetica] font-normal text-[#395a7a] text-[11px] tracking-[0] leading-[16.5px]"
                />
              </label>
              <label className="row-[2_/_3] col-[1_/_3] relative w-full h-full flex flex-col items-start">
                <span className="flex flex-col w-[608px] h-[21px] items-start pt-0 pb-1.5 px-0 relative">
                  <span className="relative w-fit mt-[-1.00px] [font-family:'Noto_Sans_KR',Helvetica] font-normal text-[#657e9b] text-[9.5px] tracking-[0] leading-[14.2px] whitespace-nowrap">
                    직무 분류
                  </span>
                </span>
                <div className="relative self-stretch w-full h-[31px] mb-[-0.75px] bg-white rounded-[5px] overflow-hidden border border-solid border-[#dfe7f0]">
                  <select
                    value={category}
                    onChange={(event) => setCategory(event.target.value)}
                    aria-label="직무 분류"
                    className="absolute inset-0 w-full px-3.5 pr-8 [font-family:'Noto_Sans_KR',Helvetica] font-normal text-[#395a7a] text-[11px] tracking-[0] leading-[normal]"
                  >
                    <option value={selectedJob.category}>
                      {selectedJob.category}
                    </option>
                    <option value="개발 · 플랫폼">개발 · 플랫폼</option>
                    <option value="디자인 · UX/UI">디자인 · UX/UI</option>
                    <option value="기획 · 서비스전략">기획 · 서비스전략</option>
                  </select>
                  <span
                    className="flex w-5 h-[29px] items-center justify-center absolute top-px right-0 pointer-events-none"
                    aria-hidden="true"
                  >
                    <span className="relative w-2.5 h-1.5">
                      <img
                        className="absolute w-[97.50%] h-[95.83%] top-[4.17%] left-[2.50%]"
                        alt=""
                        src="/img/vector-11.svg"
                      />
                    </span>
                  </span>
                </div>
              </label>
              <label className="row-[3_/_4] col-[1_/_3] relative w-full h-full flex flex-col items-start">
                <span className="flex flex-col w-[608px] h-[21px] items-start pt-0 pb-1.5 px-0 relative">
                  <span className="relative w-fit mt-[-1.00px] [font-family:'Noto_Sans_KR',Helvetica] font-normal text-[#657e9b] text-[9.5px] tracking-[0] leading-[14.2px] whitespace-nowrap">
                    설명
                  </span>
                </span>
                <textarea
                  value={description}
                  onChange={(event) => setDescription(event.target.value)}
                  aria-label="직무 설명"
                  className="flex flex-col w-[608px] h-12 items-start p-[9px] relative bg-white rounded-[5px] overflow-hidden border border-solid border-[#dfe7f0] resize-none [font-family:'Noto_Sans_KR',Helvetica] font-normal text-[#395a7a] text-[11px] tracking-[0] leading-[16.5px]"
                />
              </label>
            </div>
          </div>
          <div className="items-center pt-[17px] pb-0 px-0 flex flex-col relative self-stretch w-full flex-[0_0_auto]">
            <div className="flex items-center gap-[9px] pt-[15px] pb-0 px-0 relative self-stretch w-full flex-[0_0_auto] border-t [border-top-style:solid] border-[#edf1f5]">
              <h2 className="font-bold text-[#365775] text-[11.5px] leading-[17.2px] relative w-fit mt-[-1.00px] [font-family:'Noto_Sans_KR',Helvetica] tracking-[0] whitespace-nowrap">
                직무 정보
              </h2>
              <span className="relative w-fit mt-[-1.00px] [font-family:'Noto_Sans_KR',Helvetica] font-normal text-[#94a4b6] text-[9.5px] tracking-[0] leading-[14.2px] whitespace-nowrap">
                직무 운영에 필요한 추가 설정입니다.
              </span>
            </div>
          </div>
          <div className="items-start pt-2.5 pb-0 px-0 flex flex-col relative self-stretch w-full flex-[0_0_auto]">
            <div className="grid grid-cols-[297.50px_297.50px] grid-rows-[51.25px] h-fit gap-[11px_13px]">
              <label className="row-[1_/_2] col-[1_/_2] relative w-full h-full flex flex-col items-start">
                <span className="flex flex-col w-[297.5px] h-[21px] items-start pt-0 pb-1.5 px-0 relative">
                  <span className="relative w-fit mt-[-1.00px] [font-family:'Noto_Sans_KR',Helvetica] font-normal text-[#657e9b] text-[9.5px] tracking-[0] leading-[14.2px] whitespace-nowrap">
                    직군
                  </span>
                </span>
                <select
                  value={group}
                  onChange={(event) => setGroup(event.target.value)}
                  aria-label="직군"
                  className="flex flex-col w-[297.5px] h-[31px] items-start justify-center px-[9px] py-0 relative mb-[-0.75px] bg-white rounded-[5px] overflow-hidden border border-solid border-[#dfe7f0] [font-family:'Noto_Sans_KR',Helvetica] font-normal text-[#395a7a] text-[11px] tracking-[0] leading-[16.5px]"
                >
                  <option value={group}>{group}</option>
                  <option value="개발">개발</option>
                  <option value="디자인">디자인</option>
                  <option value="기획">기획</option>
                  <option value="경영지원">경영지원</option>
                </select>
              </label>
              <label className="row-[1_/_2] col-[2_/_3] relative w-full h-full flex flex-col items-start">
                <span className="relative w-fit mt-[-1.00px] [font-family:'Noto_Sans_KR',Helvetica] font-normal text-[#657e9b] text-[9.5px] tracking-[0] leading-[14.2px] whitespace-nowrap">
                  현재 인원
                </span>
                <span className="items-start pt-1.5 pb-0 px-0 mb-[-0.75px] flex flex-col relative self-stretch w-full flex-[0_0_auto]">
                  <span className="relative self-stretch w-full h-[31px]">
                    <input
                      type="number"
                      min="0"
                      value={headcount}
                      onChange={(event) => setHeadcount(event.target.value)}
                      aria-label="현재 인원"
                      className="flex flex-col w-[298px] h-[31px] items-start justify-center pl-[9px] pr-[30px] py-0 absolute top-0 left-0 bg-white rounded-[5px] overflow-hidden border border-solid border-[#dfe7f0] [font-family:'Noto_Sans_KR',Helvetica] font-normal text-[#395a7a] text-[11px] tracking-[0] leading-[16.5px]"
                    />
                    <span className="absolute top-[9px] right-[9px] [font-family:'Noto_Sans_KR',Helvetica] font-normal text-[#8497ae] text-[9px] tracking-[0] leading-[13.5px] whitespace-nowrap">
                      명
                    </span>
                  </span>
                </span>
              </label>
            </div>
          </div>
        </form>
        <footer className="flex w-[648px] h-[57px] items-center justify-end gap-2 px-5 py-0 absolute top-[448px] left-px bg-[#fbfcfe] border-t [border-top-style:solid] [border-right-style:none] [border-bottom-style:none] [border-left-style:none] border-[#e7edf4]">
          <div className="flex items-start relative flex-1 grow">
            <button
              type="button"
              onClick={() => selectJob(selectedJob)}
              className="all-unset box-border inline-flex h-[31px] items-center gap-[5px] px-[13px] py-0 relative flex-[0_0_auto] rounded-[5px]"
            >
              <span className="relative w-4 h-4" aria-hidden="true">
                <img
                  className="absolute w-[87.08%] h-[91.25%] top-[8.75%] left-[12.92%]"
                  alt=""
                  src="/img/vector-12.svg"
                />
              </span>
              <span className="relative w-fit [font-family:'Noto_Sans_KR',Helvetica] font-normal text-[#e65a62] text-[10.5px] text-center tracking-[0] leading-[15.8px] whitespace-nowrap">
                삭제
              </span>
            </button>
          </div>
          <button
            type="button"
            onClick={resetForm}
            className="all-unset box-border inline-flex flex-col h-[31px] items-center justify-center px-[13px] py-0 relative flex-[0_0_auto] bg-white rounded-[5px] border border-solid border-[#dae4ee]"
          >
            <span className="relative w-fit [font-family:'Noto_Sans_KR',Helvetica] font-normal text-[#647d9b] text-[10.5px] text-center tracking-[0] leading-[15.8px] whitespace-nowrap">
              취소
            </span>
          </button>
          <button
            type="submit"
            onClick={saveChanges}
            className="all-unset box-border inline-flex flex-col h-[31px] items-center justify-center px-[13px] py-0 relative flex-[0_0_auto] bg-[#15b9dc] rounded-[5px]"
          >
            <span className="relative w-fit [font-family:'Noto_Sans_KR',Helvetica] font-normal text-white text-[10.5px] text-center tracking-[0] leading-[15.8px] whitespace-nowrap">
              변경사항 저장
            </span>
          </button>
        </footer>
      </section>
    </div>
  );
};
