import { useMemo, useState, type JSX } from "react";

type JobGrade = {
  id: string;
  name: string;
  code: string;
  level: number;
  employees: number;
  description: string;
  minimumTenure: string;
  active: boolean;
};

const initialJobGrades: JobGrade[] = [
  {
    id: "01",
    name: "사원",
    code: "RANK-01",
    level: 1,
    employees: 63,
    description: "신입 및 실무 담당자에게 적용되는 기본 직급입니다.",
    minimumTenure: "1년",
    active: true,
  },
  {
    id: "02",
    name: "대리",
    code: "RANK-02",
    level: 2,
    employees: 41,
    description: "",
    minimumTenure: "",
    active: true,
  },
  {
    id: "03",
    name: "과장",
    code: "RANK-03",
    level: 3,
    employees: 28,
    description: "",
    minimumTenure: "",
    active: true,
  },
  {
    id: "04",
    name: "차장",
    code: "RANK-04",
    level: 4,
    employees: 14,
    description: "",
    minimumTenure: "",
    active: true,
  },
  {
    id: "05",
    name: "부장",
    code: "RANK-05",
    level: 5,
    employees: 9,
    description: "",
    minimumTenure: "",
    active: true,
  },
];

export const JobGradeManagementSection = (): JSX.Element => {
  const [jobGrades, setJobGrades] = useState<JobGrade[]>(initialJobGrades);
  const [selectedId, setSelectedId] = useState("01");
  const [searchTerm, setSearchTerm] = useState("");
  const [activeOnly, setActiveOnly] = useState(false);

  const selectedGrade =
    jobGrades.find((jobGrade) => jobGrade.id === selectedId) ?? jobGrades[0];

  const visibleGrades = useMemo(() => {
    const normalizedSearch = searchTerm.trim().toLowerCase();

    return jobGrades.filter((jobGrade) => {
      const matchesSearch =
        normalizedSearch.length === 0 ||
        jobGrade.name.toLowerCase().includes(normalizedSearch) ||
        jobGrade.code.toLowerCase().includes(normalizedSearch);

      return matchesSearch && (!activeOnly || jobGrade.active);
    });
  }, [activeOnly, jobGrades, searchTerm]);

  const updateSelectedGrade = (changes: Partial<JobGrade>) => {
    setJobGrades((currentGrades) =>
      currentGrades.map((jobGrade) =>
        jobGrade.id === selectedGrade.id
          ? { ...jobGrade, ...changes }
          : jobGrade,
      ),
    );
  };

  const handleDelete = () => {
    if (jobGrades.length <= 1) {
      return;
    }

    const remainingGrades = jobGrades.filter(
      (jobGrade) => jobGrade.id !== selectedGrade.id,
    );

    setJobGrades(remainingGrades);
    setSelectedId(remainingGrades[0].id);
  };

  const handleCancel = () => {
    const originalGrade = initialJobGrades.find(
      (jobGrade) => jobGrade.id === selectedGrade.id,
    );

    if (originalGrade) {
      updateSelectedGrade(originalGrade);
    }
  };

  const handleSave = () => {
    setJobGrades((currentGrades) => [...currentGrades]);
  };

  return (
    <section
      aria-label="직급 관리"
      className="grid min-h-[438px] h-fit grid-cols-1 gap-4 xl:grid-cols-[385px_650px] xl:grid-rows-[505.5px]"
    >
      <div className="relative flex h-full min-h-[438px] w-full flex-col items-start overflow-hidden rounded-lg border border-solid border-[#e1e9f2] bg-white">
        <div className="flex h-[58px] w-full items-start gap-2 border-b border-solid border-[#edf1f6] px-[13px] py-[11px]">
          <label className="flex min-w-0 flex-1 items-center gap-2 rounded-[5px] border border-solid border-[#dfe7f0] bg-[#fafcff] px-[11px]">
            <span className="relative h-[17px] w-[15.61px]" aria-hidden="true">
              <img
                className="absolute left-[12.92%] top-[15.95%] h-[84.05%] w-[87.08%]"
                alt=""
                src="/img/vector.svg"
              />
              <img
                className="absolute left-[62.92%] top-[61.86%] h-[38.14%] w-[37.08%]"
                alt=""
                src="/img/vector-1.svg"
              />
            </span>
            <input
              aria-label="직급명 또는 코드 검색"
              className="min-w-0 flex-1 bg-transparent font-['Noto_Sans_KR',Helvetica] text-[11.5px] font-normal text-[#395a7a] outline-none placeholder:text-[#97a7ba]"
              placeholder="직급명 또는 코드 검색"
              value={searchTerm}
              onChange={(event) => setSearchTerm(event.target.value)}
            />
          </label>
          <button
            type="button"
            aria-label="추가 메뉴"
            className="box-border flex h-full w-9 items-center justify-center rounded-[5px] border border-solid border-[#dfe7f0] bg-white font-['Noto_Sans_KR',Helvetica] text-base tracking-[1px] text-[#7790ad]"
          >
            •••
          </button>
        </div>
        <div className="flex h-[38px] w-full items-center justify-between bg-[#f8fafd] px-3.5">
          <span className="font-['Noto_Sans_KR',Helvetica] text-[10.5px] leading-[15.8px] text-[#7890ad]">
            전체 {jobGrades.length}개
          </span>
          <button
            type="button"
            aria-pressed={activeOnly}
            onClick={() => setActiveOnly((currentValue) => !currentValue)}
            className="font-['Noto_Sans_KR',Helvetica] text-[10.5px] leading-[15.8px] text-[#56789f]"
          >
            사용 중인 항목만
          </button>
        </div>
        <div className="flex w-full flex-col items-start px-[7px] py-[5px]">
          {visibleGrades.map((jobGrade) => {
            const isSelected = jobGrade.id === selectedGrade.id;
            const isFinalGrade = jobGrade.level === 5;

            return (
              <button
                type="button"
                key={jobGrade.id}
                onClick={() => setSelectedId(jobGrade.id)}
                aria-pressed={isSelected}
                className={`flex h-[58px] w-full items-center gap-2.5 border-b border-solid px-2.5 py-2 text-left ${
                  isSelected
                    ? "rounded-md border-transparent bg-[#cff7ff]"
                    : "border-[#edf1f5] bg-white"
                }`}
              >
                <span
                  className={`grid h-[27px] w-[27px] place-items-center rounded-md font-['Noto_Sans_KR',Helvetica] text-[9px] leading-[13.5px] ${
                    isSelected
                      ? "bg-[#dbeaff] text-[#1973e8]"
                      : "bg-[#f0f4f8] text-[#7d93ad]"
                  }`}
                >
                  {jobGrade.id}
                </span>
                <span className="flex min-w-0 flex-1 flex-col items-start">
                  <strong className="font-['Noto_Sans_KR',Helvetica] text-xs leading-[18px] text-[#294968]">
                    {jobGrade.name}
                  </strong>
                  <span className="pt-[5px] font-['Noto_Sans_KR',Helvetica] text-[9.5px] leading-[14.2px] text-[#8799ae]">
                    {jobGrade.code} · {jobGrade.level}단계
                    {jobGrade.level === 1 ? " · 기본 직급" : ""}
                    {isFinalGrade ? " · 최고 직급" : ""}
                  </span>
                </span>
                <span className="flex items-baseline gap-1 font-['Noto_Sans_KR',Helvetica]">
                  <strong className="text-xs leading-[18px] text-[#365c85]">
                    {jobGrade.employees}
                  </strong>
                  <span className="text-[9px] leading-[13.5px] text-[#8799ae]">
                    명
                  </span>
                </span>
                <span className="relative h-4 w-4" aria-hidden="true">
                  <img
                    className="absolute left-[33.75%] top-[21.25%] h-[78.75%] w-[66.25%]"
                    alt=""
                    src={
                      isFinalGrade ? "/img/vector-6.svg" : "/img/vector-4.svg"
                    }
                  />
                </span>
              </button>
            );
          })}
        </div>
        <div className="mt-auto flex h-[39px] w-full items-center gap-[7px] border-t border-solid border-[#e9eef4] bg-[#fafcff] px-3.5">
          <span className="relative h-[15px] w-[15px]" aria-hidden="true">
            <img
              className="absolute left-[4.58%] top-[4.58%] h-[95.42%] w-[95.42%]"
              alt=""
              src="/img/vector-7.svg"
            />
            <img
              className="absolute left-[46.25%] top-[25.42%] h-[74.58%] w-[53.75%]"
              alt=""
              src="/img/vector-8.svg"
            />
          </span>
          <p className="font-['Noto_Sans_KR',Helvetica] text-[9.5px] leading-[14.2px] text-[#7b90a9]">
            항목을 선택하면 상세 정보를 수정할 수 있습니다.
          </p>
        </div>
      </div>
      <div className="relative flex h-full min-h-[505.5px] w-full flex-col overflow-hidden rounded-lg border border-solid border-[#e1e9f2] bg-white xl:pb-[58px]">
        <header className="flex h-[78px] w-full items-center gap-[13px] border-b border-solid border-[#e8edf3] px-5">
          <div className="grid h-[42px] w-[42px] place-items-center rounded-[9px] bg-[#e5f8f5]">
            <span className="relative h-[25px] w-[25px]" aria-hidden="true">
              <img
                className="absolute left-[21.25%] top-[8.75%] h-[91.25%] w-[78.75%]"
                alt=""
                src="/img/vector-9.svg"
              />
              <img
                className="absolute left-[33.75%] top-[25.42%] h-[74.58%] w-[66.25%]"
                alt=""
                src="/img/vector-10.svg"
              />
            </span>
          </div>
          <div className="flex flex-col">
            <span className="font-['Noto_Sans_KR',Helvetica] text-[9px] leading-[13.5px] tracking-[0.36px] text-[#7e93ad]">
              {selectedGrade.code}
            </span>
            <span className="pt-1 font-['Noto_Sans_KR',Helvetica] text-base leading-6 text-[#193a61]">
              {selectedGrade.name}
            </span>
          </div>
        </header>
        <form
          className="flex flex-col px-5 pt-[17px]"
          onSubmit={(event) => {
            event.preventDefault();
            handleSave();
          }}
        >
          <div className="flex items-center gap-[9px]">
            <h2 className="font-['Noto_Sans_KR',Helvetica] text-[11.5px] font-bold leading-[17.2px] text-[#365775]">
              기본 정보
            </h2>
            <span className="font-['Noto_Sans_KR',Helvetica] text-[9.5px] leading-[14.2px] text-[#94a4b6]">
              필수 정보를 입력해주세요.
            </span>
          </div>
          <div className="grid gap-[11px] pt-3 sm:grid-cols-2">
            <label className="flex flex-col gap-1.5">
              <span className="font-['Noto_Sans_KR',Helvetica] text-[9.5px] text-[#657e9b]">
                직급명 <b className="text-[#ed5862]">*</b>
              </span>
              <input
                required
                value={selectedGrade.name}
                onChange={(event) =>
                  updateSelectedGrade({ name: event.target.value })
                }
                className="h-[31px] rounded-[5px] border border-solid border-[#dfe7f0] px-[9px] font-['Noto_Sans_KR',Helvetica] text-[11px] text-[#395a7a] outline-none"
              />
            </label>
            <label className="flex flex-col gap-1.5">
              <span className="font-['Noto_Sans_KR',Helvetica] text-[9.5px] text-[#657e9b]">
                직급 코드 <b className="text-[#ed5862]">*</b>
              </span>
              <input
                required
                value={selectedGrade.code}
                onChange={(event) =>
                  updateSelectedGrade({ code: event.target.value })
                }
                className="h-[31px] rounded-[5px] border border-solid border-[#dfe7f0] px-[9px] font-['Noto_Sans_KR',Helvetica] text-[11px] text-[#395a7a] outline-none"
              />
            </label>
            <label className="flex flex-col gap-1.5 sm:col-span-2">
              <span className="font-['Noto_Sans_KR',Helvetica] text-[9.5px] text-[#657e9b]">
                직급 단계
              </span>
              <div className="relative">
                <select
                  value={selectedGrade.level}
                  onChange={(event) =>
                    updateSelectedGrade({
                      level: Number(event.target.value),
                    })
                  }
                  className="h-[31px] w-full appearance-none rounded-[5px] border border-solid border-[#dfe7f0] bg-white px-3.5 font-['Noto_Sans_KR',Helvetica] text-[11px] text-[#395a7a] outline-none"
                >
                  {jobGrades.map((jobGrade) => (
                    <option key={jobGrade.level} value={jobGrade.level}>
                      {jobGrade.level}단계 ·{" "}
                      {jobGrade.level === 1 ? "기본 직급" : jobGrade.name}
                    </option>
                  ))}
                </select>
                <img
                  className="pointer-events-none absolute right-3 top-2.5 h-1.5 w-2.5"
                  alt=""
                  src="/img/vector-11.svg"
                />
              </div>
            </label>
            <label className="flex flex-col gap-1.5 sm:col-span-2">
              <span className="font-['Noto_Sans_KR',Helvetica] text-[9.5px] text-[#657e9b]">
                설명
              </span>
              <textarea
                value={selectedGrade.description}
                onChange={(event) =>
                  updateSelectedGrade({ description: event.target.value })
                }
                className="h-12 resize-none rounded-[5px] border border-solid border-[#dfe7f0] p-[9px] font-['Noto_Sans_KR',Helvetica] text-[11px] leading-[16.5px] text-[#395a7a] outline-none"
              />
            </label>
          </div>
          <div className="mt-[17px] border-t border-solid border-[#edf1f5] pt-[15px]">
            <div className="flex items-center gap-[9px]">
              <h2 className="font-['Noto_Sans_KR',Helvetica] text-[11.5px] font-bold leading-[17.2px] text-[#365775]">
                승진 기준
              </h2>
              <span className="font-['Noto_Sans_KR',Helvetica] text-[9.5px] leading-[14.2px] text-[#94a4b6]">
                직급 운영에 필요한 추가 설정입니다.
              </span>
            </div>
            <div className="grid gap-[11px] pt-2.5 sm:grid-cols-2">
              <label className="flex flex-col gap-1.5">
                <span className="font-['Noto_Sans_KR',Helvetica] text-[9.5px] text-[#657e9b]">
                  최소 체류기간
                </span>
                <input
                  value={selectedGrade.minimumTenure}
                  onChange={(event) =>
                    updateSelectedGrade({
                      minimumTenure: event.target.value,
                    })
                  }
                  className="h-[31px] rounded-[5px] border border-solid border-[#dfe7f0] px-[9px] font-['Noto_Sans_KR',Helvetica] text-[11px] text-[#395a7a] outline-none"
                />
              </label>
              <label className="flex flex-col gap-1.5">
                <span className="font-['Noto_Sans_KR',Helvetica] text-[9.5px] text-[#657e9b]">
                  현재 인원
                </span>
                <div className="relative">
                  <input
                    type="number"
                    min="0"
                    value={selectedGrade.employees}
                    onChange={(event) =>
                      updateSelectedGrade({
                        employees: Number(event.target.value),
                      })
                    }
                    className="h-[31px] w-full rounded-[5px] border border-solid border-[#dfe7f0] px-[9px] pr-8 font-['Noto_Sans_KR',Helvetica] text-[11px] text-[#395a7a] outline-none"
                  />
                  <span className="absolute right-2 top-2 font-['Noto_Sans_KR',Helvetica] text-[9px] text-[#8497ae]">
                    명
                  </span>
                </div>
              </label>
            </div>
          </div>
        </form>
        <footer className="absolute bottom-0 left-0 flex h-[57px] w-full items-center justify-end gap-2 border-t border-solid border-[#e7edf4] bg-[#fbfcfe] px-5">
          <div className="flex flex-1">
            <button
              type="button"
              onClick={handleDelete}
              className="inline-flex h-[31px] items-center gap-[5px] rounded-[5px] px-[13px] font-['Noto_Sans_KR',Helvetica] text-[10.5px] text-[#e65a62]"
            >
              <img className="h-4 w-4" alt="" src="/img/vector-12.svg" />
              삭제
            </button>
          </div>
          <button
            type="button"
            onClick={handleCancel}
            className="h-[31px] rounded-[5px] border border-solid border-[#dae4ee] bg-white px-[13px] font-['Noto_Sans_KR',Helvetica] text-[10.5px] text-[#647d9b]"
          >
            취소
          </button>
          <button
            type="submit"
            onClick={handleSave}
            className="h-[31px] rounded-[5px] bg-[#15b9dc] px-[13px] font-['Noto_Sans_KR',Helvetica] text-[10.5px] text-white"
          >
            변경사항 저장
          </button>
        </footer>
      </div>
    </section>
  );
};
