// src/api/organizationApi.ts
import { apiGet } from "./client";

export type CompanyData = {
  companyName: string;
  businessNumber: string;
  representative: string;
  foundedDate: string;
  address: string;
  phone: string;
  email: string;
  homepage: string;
  industry: string;
};

// ORG-01: 회사 정보 조회 (GET /api/v1/company)
export async function getCompanyInfo(): Promise<CompanyData> {
  return apiGet<CompanyData>("/company");
}

// ORG-02: 회사 정보 수정 (PATCH /api/v1/company)
export async function updateCompanyInfo(data: Partial<CompanyData>): Promise<CompanyData> {
  const response = await fetch("/api/v1/company", {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });
  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err.message || "회사 정보 수정에 실패했습니다.");
  }
  return response.json();
}

// ORG-24: 회사 로고 업로드 (POST /api/v1/company/logo)
export async function uploadCompanyLogoApi(file: File): Promise<any> {
  const formData = new FormData();
  formData.append("logo", file);

  const response = await fetch("/api/v1/company/logo", {
    method: "POST",
    body: formData, // multipart/form-data
  });
  if (!response.ok) {
    throw new Error("회사 로고 업로드에 실패했습니다.");
  }
  return response.json();
}

import { type ChangeEvent, type FormEvent, type JSX, useEffect, useMemo, useRef, useState } from "react";
import { getCompanyInfo, updateCompanyInfo, uploadCompanyLogoApi, type CompanyData } from "../../api/organizationApi";

const companyFields = [
  { key: "companyName", label: "회사명" },
  { key: "businessNumber", label: "사업자등록번호" },
  { key: "representative", label: "대표자명" },
  { key: "foundedDate", label: "설립일" },
  { key: "address", label: "회사주소" },
  { key: "phone", label: "연락처" },
  { key: "email", label: "이메일" },
  { key: "homepage", label: "홈페이지" },
  { key: "industry", label: "업종" },
] as const;

const previewFields = [
  { label: "대표자명", value: (c: CompanyData) => c.representative },
  { label: "설립일", value: (c: CompanyData) => c.foundedDate?.replaceAll("-", ".") },
  { label: "사업자등록번호", value: (c: CompanyData) => c.businessNumber },
  { label: "주소", value: (c: CompanyData) => c.address },
  { label: "연락처", value: (c: CompanyData) => c.phone },
  { label: "이메일", value: (c: CompanyData) => c.email },
  { label: "홈페이지", value: (c: CompanyData) => c.homepage },
];

export const CompanyInformationSection = (): JSX.Element => {
  const [company, setCompany] = useState<CompanyData>({
    companyName: "",
    businessNumber: "",
    representative: "",
    foundedDate: "",
    address: "",
    phone: "",
    email: "",
    homepage: "",
    industry: "",
  });
  const [savedCompany, setSavedCompany] = useState<CompanyData>(company);
  const [loading, setLoading] = useState(true);
  const [notice, setNotice] = useState("");
  const [isAddressMessageVisible, setIsAddressMessageVisible] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // ORG-01: 컴포넌트 마운트 시 회사 정보 조회
  useEffect(() => {
    let cancelled = false;
    const fetchCompany = async () => {
      try {
        setLoading(true);
        const data = await getCompanyInfo();
        if (!cancelled) {
          setCompany(data);
          setSavedCompany(data);
        }
      } catch (err) {
        if (!cancelled) setNotice("회사 정보를 불러오지 못했습니다.");
      } finally {
        if (!cancelled) setLoading(false);
      }
    };
    void fetchCompany();
    return () => {
      cancelled = true;
    };
  }, []);

  const displayCompany = useMemo(() => company, [company]);

  const updateField = (key: keyof CompanyData, value: string) => {
    setCompany((current) => ({ ...current, [key]: value }));
  };

  const handleChange = (key: keyof CompanyData) => (event: ChangeEvent<HTMLInputElement>) => {
    updateField(key, event.target.value);
  };

  // ORG-02: 회사 정보 수정 제출 (PATCH /company)
  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    try {
      setLoading(true);
      const updated = await updateCompanyInfo(company);
      setCompany(updated);
      setSavedCompany(updated);
      setNotice("회사 정보가 수정되었습니다.");
    } catch (err) {
      setNotice(err instanceof Error ? err.message : "수정에 실패했습니다.");
    } finally {
      setLoading(false);
    }
  };

  const handleCancel = () => {
    setCompany(savedCompany);
    setNotice("");
  };

  const handleAddressSearch = () => {
    setIsAddressMessageVisible(true);
  };

  // ORG-24: 회사 로고 업로드 (POST /company/logo)
  const handleFileChange = async (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      try {
        setLoading(true);
        await uploadCompanyLogoApi(file);
        setNotice("회사 로고가 변경되었습니다.");
        setIsAddressMessageVisible(false);
      } catch (err) {
        setNotice("로고 업로드에 실패했습니다.");
      } finally {
        setLoading(false);
      }
    }
  };

  if (loading && !company.companyName) {
    return <div className="p-6 text-sm text-[#607a9b]">회사 정보를 불러오는 중...</div>;
  }

  return (
    <div className="grid grid-cols-[970.14px_495.84px] grid-rows-[503px] h-fit gap-[18px] pt-[18px] pb-0 px-0">
      <form
        aria-label="회사 기본정보"
        onSubmit={handleSubmit}
        className="relative row-[1_/_2] col-[1_/_2] w-full min-h-[478px] h-full flex flex-col items-start pt-0 pb-[58px] px-[22px] bg-white rounded-lg border border-solid border-[#e5ebf3]"
      >
        <div className="flex h-[54px] items-center gap-[13px] relative self-stretch w-full border-b border-[#e8edf4]">
          <h2 className="text-[#17335a] text-sm font-normal">회사 기본정보</h2>
          {notice && <span className="ml-auto text-xs text-[#15b9dc]">{notice}</span>}
        </div>

        <div className="flex flex-col items-start pt-[9px] pb-0 px-0 relative self-stretch w-full">
          {companyFields.map((field) => (
            <div key={field.key} className="grid grid-cols-[155px_769.14px] min-h-9 h-fit my-1">
              <div className="self-center pl-2">
                <label htmlFor={`company-${field.key}`} className="text-[#607a9b] text-xs">
                  {field.label}
                </label>
              </div>
              <div className="self-center">
                {field.key === "foundedDate" ? (
                  <input
                    id="company-foundedDate"
                    type="date"
                    value={company.foundedDate || ""}
                    onChange={handleChange("foundedDate")}
                    className="w-[769px] h-[30px] px-2.5 bg-white rounded border border-[#e5ebf3] text-xs text-[#345477]"
                  />
                ) : field.key === "address" ? (
                  <div className="grid grid-cols-[656.14px_105px] gap-2">
                    <input
                      id="company-address"
                      type="text"
                      value={company.address || ""}
                      onChange={handleChange("address")}
                      className="w-full h-[30px] px-2.5 bg-white rounded border border-[#e5ebf3] text-xs text-[#345477]"
                    />
                    <button
                      type="button"
                      onClick={handleAddressSearch}
                      className="h-[30px] bg-white rounded border border-[#dae4ef] text-[11px] text-[#527398]"
                    >
                      주소 검색
                    </button>
                  </div>
                ) : field.key === "industry" ? (
                  <select
                    id="company-industry"
                    value={company.industry || ""}
                    onChange={(e) => updateField("industry", e.target.value)}
                    className="w-60 h-[30px] px-3 bg-white rounded border border-[#e5ebf3] text-xs text-[#345477]"
                  >
                    <option value="">업종 선택</option>
                    <option value="IT 서비스업">IT 서비스업</option>
                    <option value="제조업">제조업</option>
                    <option value="금융업">금융업</option>
                    <option value="교육 서비스업">교육 서비스업</option>
                  </select>
                ) : (
                  <input
                    id={`company-${field.key}`}
                    type={field.key === "email" ? "email" : "text"}
                    value={company[field.key] || ""}
                    onChange={handleChange(field.key)}
                    className="w-[769px] h-[30px] px-2.5 bg-white rounded border border-[#e5ebf3] text-xs text-[#345477]"
                  />
                )}
              </div>
            </div>
          ))}

          {/* 로고 업로드 영역 */}
          <div className="grid grid-cols-[155px_769.14px] min-h-9 my-2">
            <div className="self-center pl-2">
              <span className="text-[#607a9b] text-xs">회사 로고</span>
            </div>
            <div className="flex items-center gap-3">
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleFileChange}
                className="sr-only"
                aria-label="회사 로고 이미지 선택"
              />
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="h-[30px] px-3 bg-white rounded border border-[#dae4ef] text-[11px] text-[#527398]"
              >
                이미지 변경
              </button>
            </div>
          </div>
        </div>

        <div className="inline-flex items-center gap-2.5 absolute top-[448px] left-[765px]">
          <button
            type="button"
            onClick={handleCancel}
            className="w-[86px] h-9 bg-white rounded-md border border-[#dbe5f0] text-xs text-[#607a9d]"
          >
            취소
          </button>
          <button
            type="submit"
            disabled={loading}
            className="w-[86px] h-9 bg-[#15b9dc] rounded-md text-xs text-white"
          >
            {loading ? "저장 중..." : "저장"}
          </button>
        </div>
      </form>

      {/* 미리보기 패널 */}
      <aside className="relative row-[1_/_2] col-[2_/_3] w-full h-full flex flex-col items-start gap-3.5">
        <div className="flex flex-col min-h-[381px] items-start pt-0 pb-[18px] px-5 relative self-stretch w-full bg-white rounded-lg border border-[#e5ebf3]">
          <div className="flex w-[453.84px] h-[53px] items-center justify-between">
            <h2 className="text-[#17335a] text-sm">회사 정보 미리보기</h2>
          </div>
          <div className="flex w-[453.84px] h-20 items-center gap-4 px-[18px] rounded-t-lg border border-[#e5ebf3]">
            <div className="flex flex-col">
              <strong className="text-[#17335a] text-base">{displayCompany.companyName}</strong>
              <span className="text-[#7b90aa] text-xs">Princess Co., Ltd.</span>
            </div>
          </div>
          <div className="grid grid-cols-[105px_310.84px] gap-[11px_0px] pt-3.5 pb-2.5 px-[18px] border border-t-0 rounded-b-lg border-[#e5ebf3] w-full">
            {previewFields.map((field) => (
              <div key={field.label} className="flex flex-col">
                <span className="text-[#7287a4] text-[11.5px]">{field.label}</span>
                <span className="text-[#365474] text-[11.5px]">{field.value(displayCompany)}</span>
              </div>
            ))}
          </div>
        </div>
      </aside>
    </div>
  );
};